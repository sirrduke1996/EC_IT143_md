-- Step 8: Call the Stored Procedure
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Execute the stored procedure to refresh the table
EXEC dbo.sp_LoadTeamPlayerCount;
