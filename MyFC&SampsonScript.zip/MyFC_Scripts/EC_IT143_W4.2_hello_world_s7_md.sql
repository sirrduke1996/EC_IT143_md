-- Step 7: Turn Ad Hoc Script into a Stored Procedure
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Create or alter stored procedure
CREATE OR ALTER PROCEDURE dbo.sp_LoadTeamPlayerCount
AS
BEGIN
    SET NOCOUNT ON;

    -- Step 1: Clear existing data
    TRUNCATE TABLE dbo.tblTeamPlayerCount;

    -- Step 2: Insert fresh data from the view
    INSERT INTO dbo.tblTeamPlayerCount (TeamName, NumberOfPlayers)
    SELECT TeamName, NumberOfPlayers
    FROM dbo.vw_TeamPlayerCount;

    -- Step 3: Optional - show results
    SELECT * FROM dbo.tblTeamPlayerCount
    ORDER BY NumberOfPlayers DESC;
END;
GO
