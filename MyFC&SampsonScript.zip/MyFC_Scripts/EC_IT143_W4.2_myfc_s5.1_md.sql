-- Step 5.1: Create Table from View
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Create a physical table called tblTeamPlayerCount
SELECT *
INTO dbo.tblTeamPlayerCount
FROM dbo.vw_TeamPlayerCount;

-- Verify the table
SELECT * FROM dbo.tblTeamPlayerCount;
