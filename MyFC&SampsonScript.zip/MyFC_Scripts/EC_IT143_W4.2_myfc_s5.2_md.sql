-- Step 5.2: Refine Table
-- Add primary key and constraints

ALTER TABLE dbo.tblTeamPlayerCount
ADD TeamID INT IDENTITY(1,1) PRIMARY KEY;

-- Optional: Add NOT NULL constraint if needed
ALTER TABLE dbo.tblTeamPlayerCount
ALTER COLUMN TeamName VARCHAR(50) NOT NULL;

-- Verify the final table
SELECT * FROM dbo.tblTeamPlayerCount;
