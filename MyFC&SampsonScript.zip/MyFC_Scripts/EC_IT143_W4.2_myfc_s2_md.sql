-- Step 2: Begin Creating an Answer
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Answer Plan:
-- 1. Use the Players table to get all players and their TeamID.
-- 2. Join the Players table with the Teams table using TeamID to get team names.
-- 3. Count the number of players per team.
-- 4. The result will show each team and the total number of players in that team.
