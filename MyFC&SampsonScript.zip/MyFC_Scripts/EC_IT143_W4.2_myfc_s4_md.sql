-- Step 4: Turn Ad Hoc Query into a View
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Create a view called vw_TeamPlayerCount
CREATE OR ALTER VIEW dbo.vw_TeamPlayerCount
AS
SELECT 
    t.t_code AS TeamName,
    COUNT(p.pl_id) AS NumberOfPlayers
FROM 
    dbo.tblPlayerDim p
JOIN 
    dbo.tblTeamDim t
    ON p.t_id = t.t_id
GROUP BY 
    t.t_code;
GO

-- Test the view
SELECT * FROM dbo.vw_TeamPlayerCount
ORDER BY NumberOfPlayers DESC;
