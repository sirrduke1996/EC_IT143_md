-- Step 6: Load the Table from the View
-- Dataset: MyFC (Soccer)
-- Question: How many players are on each team?

-- Clear existing data
TRUNCATE TABLE dbo.tblTeamPlayerCount;

-- Insert fresh data from the view
INSERT INTO dbo.tblTeamPlayerCount (TeamName, NumberOfPlayers)
SELECT TeamName, NumberOfPlayers
FROM dbo.vw_TeamPlayerCount;

-- Verify the table
SELECT * FROM dbo.tblTeamPlayerCount
ORDER BY NumberOfPlayers DESC;
