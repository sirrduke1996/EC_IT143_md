-- Step 1: Start with a Question
-- Dataset: Sampson (Credit Card Transactions)
-- Question: What is the total transaction amount per customer?

-- Simple question plan:
-- 1. Identify customers and their transactions.
-- 2. Sum transactions per customer.
