-- Step 7: Create Stored Procedure
-- Dataset: Sampson (Credit Card Transactions)
-- Question: Total credit per member

CREATE OR ALTER PROCEDURE dbo.sp_LoadCustomerTotalCredit
AS
BEGIN
    SET NOCOUNT ON;

    -- Clear existing data
    TRUNCATE TABLE dbo.tblCustomerTotalCredit;

    -- Insert fresh data from the view
    INSERT INTO dbo.tblCustomerTotalCredit (MemberName, TotalCredit)
    SELECT MemberName, TotalCredit
    FROM dbo.vw_CustomerTotalCredit;

    -- Show results
    SELECT * FROM dbo.tblCustomerTotalCredit
    ORDER BY TotalCredit DESC;
END;
GO
