-- Step 6: Load Table from View
-- Dataset: Sampson (Credit Card Transactions)
-- Question: Total credit per member

-- Clear existing data in the table
TRUNCATE TABLE dbo.tblCustomerTotalCredit;

-- Insert fresh data from the view
INSERT INTO dbo.tblCustomerTotalCredit (MemberName, TotalCredit)
SELECT MemberName, TotalCredit
FROM dbo.vw_CustomerTotalCredit;

-- Verify the table
SELECT * FROM dbo.tblCustomerTotalCredit
ORDER BY TotalCredit DESC;
