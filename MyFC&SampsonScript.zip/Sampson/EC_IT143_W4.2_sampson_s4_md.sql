-- Step 4: Create View
-- Dataset: Sampson (Credit Card Transactions)
-- Question: Total credit per member

CREATE OR ALTER VIEW dbo.vw_CustomerTotalCredit
AS
SELECT 
    f.[Name] AS MemberName,
    SUM(t.[Credit]) AS TotalCredit
FROM 
    dbo.FBS_Viza_Costmo t
JOIN 
    dbo.Family_Data f
    ON t.[Member_Name] = f.[Name]
GROUP BY 
    f.[Name];
GO

-- Test the view
SELECT * FROM dbo.vw_CustomerTotalCredit
ORDER BY TotalCredit DESC;
