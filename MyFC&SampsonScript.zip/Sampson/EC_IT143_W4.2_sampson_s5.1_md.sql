-- Step 5.1: Create Table from View
-- Dataset: Sampson (Credit Card Transactions)
-- Question: Total credit per member

-- Create a physical table from the view
SELECT *
INTO dbo.tblCustomerTotalCredit
FROM dbo.vw_CustomerTotalCredit;

-- Verify the table
SELECT * FROM dbo.tblCustomerTotalCredit
ORDER BY TotalCredit DESC;
