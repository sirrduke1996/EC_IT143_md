-- Step 2: Begin Creating an Answer
-- Dataset: Sampson
-- Question: Total transaction amount per customer

-- Answer plan:
-- 1. Use Transactions table for transaction amounts and customer IDs.
-- 2. Join with Customer table to get customer names.
-- 3. Aggregate total transaction amount per customer.
