-- Step 5.2: Add Primary Key and Constraints
-- Add an ID column as Primary Key
ALTER TABLE dbo.tblCustomerTotalCredit
ADD CustomerCreditID INT IDENTITY(1,1) PRIMARY KEY;

-- Make MemberName NOT NULL
ALTER TABLE dbo.tblCustomerTotalCredit
ALTER COLUMN MemberName NVARCHAR(255) NOT NULL;

-- Verify the table structure
SELECT * FROM dbo.tblCustomerTotalCredit;
