-- Step 3: Ad Hoc SQL Query for Sampson Dataset
-- Question: Total credit per member

SELECT 
    f.[Name] AS MemberName,
    SUM(t.[Credit]) AS TotalCredit
FROM 
    dbo.FBS_Viza_Costmo t
JOIN 
    dbo.Family_Data f
    ON t.[Member_Name] = f.[Name]   -- join using correct column
GROUP BY 
    f.[Name]
ORDER BY
    TotalCredit DESC;
