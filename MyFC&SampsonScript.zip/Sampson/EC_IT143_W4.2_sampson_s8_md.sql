-- Step 8: Call the Stored Procedure
-- Dataset: Sampson (Credit Card Transactions)
-- Question: Total credit per member

-- Execute the stored procedure to refresh the table
EXEC dbo.sp_LoadCustomerTotalCredit;
